# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is the OpenJDK (Java Development Kit) repository - the reference implementation of Java SE. It contains:
- **HotSpot VM**: High-performance Java Virtual Machine written in C++
- **Java class libraries**: Core Java APIs organized as modules (java.base, java.desktop, etc.)
- **Development tools**: javac compiler, javadoc, jlink, jpackage, etc.
- **Native code**: Platform-specific implementations for Linux, macOS, Windows, AIX

## Build Commands

### Initial Setup
```bash
# Configure the build (run once or when dependencies change)
bash configure

# With custom options (e.g., specify boot JDK, debug build)
bash configure --with-boot-jdk=/path/to/jdk --with-debug-level=slowdebug

# For jtreg tests, specify jtreg location if not auto-detected
bash configure --with-jtreg=/path/to/jtreg

# For microbenchmarks (JMH), get dependencies first
sh make/devkit/createJMHBundle.sh
bash configure --with-jmh=build/jmh/jars
```

### Build Targets
```bash
# Full build (recommended for first time)
make images

# Faster incremental builds after source changes
make jdk
make hotspot

# Build specific modules
make java.base
make java.desktop

# Build without running tests
make exploded-image

# Clean build
make clean
make dist-clean  # Complete clean including configuration
```

### Verify Build
```bash
# Check the built JDK version
./build/*/images/jdk/bin/java -version
```

## Testing Commands

### Test Tiers
Run tests in ascending order of comprehensiveness. Always run at least tier1 before submitting changes.

```bash
# Tier 1 - Fast, fundamental tests (~10 min on typical hardware)
# Run these for every significant change
make test-tier1

# Tier 2 - More comprehensive, longer-running tests
make test-tier2

# Tier 3 - Stress tests, corner cases (use TEST_JOBS=1 or JTREG_KEYWORDS=!headful)
make test-tier3

# Tier 4 - Full test suite including vmTestbase (takes many hours)
make test-tier4
```

### Component-Specific Tests
```bash
# HotSpot tests
make test TEST=hotspot:hotspot_gc
make test TEST=hotspot:hotspot_compiler
make test TEST=hotspot:hotspot_runtime
make test TEST=hotspot:hotspot_serviceability

# JDK library tests
make test TEST=jdk:jdk_lang
make test TEST=jdk:jdk_util
make test TEST=jdk:jdk_net
make test TEST=jdk:jdk_io

# Langtools (javac, javadoc) tests
make test TEST=langtools

# Native HotSpot unit tests (gtest)
make test TEST=gtest
make test TEST="gtest:LogTagSet"

# Microbenchmarks (JMH)
make test TEST=micro:java.lang.reflect
```

### Test Options
```bash
# Control parallelism
make test TEST=tier1 JTREG="JOBS=8"

# Set timeout factor for slower systems
make test TEST=hotspot:hotspot_gc JTREG="TIMEOUT_FACTOR=4"

# Pass JVM options to tests
make test TEST=tier1 JTREG="JAVA_OPTIONS=-Xlog:gc"

# Run specific test file
make test TEST=test/hotspot/jtreg/runtime/cds/SharedStrings.java

# Run test without rebuilding (faster for reruns)
make test-only TEST=tier1
make exploded-test TEST=tier1  # Use exploded image (faster rebuild times)
```

## Codebase Architecture

### Source Structure (`src/`)
- **hotspot/**: HotSpot VM implementation (C++)
  - `share/`: Platform-independent code
    - `adlc/`: Architecture description language compiler
    - `c1/`: C1 (client) JIT compiler
    - `opto/`: C2 (server) JIT compiler (optimizing)
    - `gc/`: Garbage collectors (G1, Serial, Parallel, ZGC, Shenandoah)
    - `runtime/`: VM runtime (threads, synchronization, JNI)
    - `classfile/`: Class file parsing and linking
    - `interpreter/`: Bytecode interpreter
    - `prims/`: VM primitives (JNI, JVMTI, JVM_* functions)
    - `services/`: Diagnostic and management services
    - `memory/`: Memory management
    - `oops/`: Object-oriented pointers (object representation)
  - `cpu/`: CPU-specific code (x86, aarch64, etc.)
  - `os/`: OS-specific code (linux, bsd, windows, aix)
  - `os_cpu/`: OS and CPU-specific combinations

- **Module structure**: Java code organized as JPMS modules
  - `java.base/`: Core Java SE APIs (java.lang, java.util, java.io, java.nio, etc.)
  - `java.desktop/`: GUI libraries (AWT, Swing, 2D graphics)
  - `java.compiler/`: Java compiler API
  - `jdk.compiler/`: javac implementation
  - `jdk.hotspot.agent/`: Serviceability Agent (HotSpot debugger)
  - `jdk.jdi/`: Java Debug Interface
  - `jdk.jfr/`: Java Flight Recorder
  - `jdk.jlink/`: jlink tool for creating custom runtime images
  - Each module has: `share/classes/` (Java), `share/native/` (C/C++), platform-specific dirs

### Test Structure (`test/`)
- **hotspot/jtreg/**: HotSpot jtreg tests
  - Organized by component: `compiler/`, `gc/`, `runtime/`, `serviceability/`
  - `TEST.groups`: Defines test groups (tier1, hotspot_gc, etc.)
- **jdk/**: JDK library jtreg tests
  - Organized by package: `java/lang/`, `java/util/`, `javax/swing/`, etc.
- **langtools/**: Compiler and tools tests
- **micro/**: JMH microbenchmarks
- **lib-test/**: Test library self-tests
- **hotspot/gtest/**: Native unit tests using Google Test

### Build System (`make/`)
- Uses GNU Make with `.gmk` files
- `Makefile` → `PreInit.gmk` → Main build logic
- Key targets defined in: `Bundles.gmk`, `CompileJavaModules.gmk`, `Images.gmk`
- Auto-generated IDE project files: `make vscode-project`, `make hotspot-ide-project`

## Component-Specific Documentation

For detailed information about specific OpenJDK subsystems, see the `.claude/` directory:

- **[Java Flight Recorder (JFR)](.claude/jfr.md)**: Comprehensive guide to JFR architecture, event system, recording lifecycle, testing, and development. Essential reading for anyone working on JFR, profiling, or diagnostics features.

## Development Workflow

### Making Changes to HotSpot (C++)
1. Edit C++ source in `src/hotspot/`
2. Build: `make hotspot`
3. Test: `make test-tier1` (minimum) or component-specific tests
4. Verify with debug build: configure with `--with-debug-level=slowdebug`

### Making Changes to Java Libraries
1. Edit Java source in `src/<module>/share/classes/`
2. Build: `make jdk` or `make <module-name>`
3. Test: `make test TEST=jdk:<test-group>` or specific test paths
4. For faster iteration: `make exploded-test TEST=...`

### Running Individual Tests
```bash
# Direct jtreg invocation (alternative to make test)
# Useful for more control, but make test is usually easier
build/*/jdk/bin/jtreg -jdk:build/*/images/jdk test/hotspot/jtreg/gc/TestGC.java
```

## IDE Support

### IntelliJ IDEA (Java code)
```bash
bash bin/idea.sh
# Open the generated workspace in IntelliJ
# Set Project SDK to: build/<config>/images/jdk
```

### Visual Studio Code (C++ code)
```bash
make vscode-project
# Open jdk.code-workspace in VS Code
# For clangd indexing: make vscode-project-clangd
```

### Eclipse
```bash
make eclipse-java-env      # Java development
make eclipse-native-env    # C++ development
make eclipse-mixed-env     # Both Java and C++
```

## Coding Conventions

### C++ (HotSpot)
- Code style documented in `doc/hotspot-style.md`
- Use HotSpot-specific types: `intptr_t`, `uintptr_t`, `jint`, `jlong`
- Object types: `oop` (ordinary object pointer), `Klass*` (class metadata)
- Memory allocation: Use resource areas, handles, or C-heap depending on lifetime
- Always check for null and handle errors appropriately
- Use `assert()` for debug-mode checks, `guarantee()` for checks that remain in product builds

### Java (Libraries)
- Follow standard Java conventions
- Package-private classes in `sun.*` and `jdk.internal.*` for implementation details
- Public APIs in `java.*` and `javax.*` must maintain compatibility
- Use `@implSpec`, `@implNote` for implementation documentation

## Common Tasks

### Adding a New Test
1. Create test file in appropriate `test/` subdirectory
2. Add jtreg tags: `@test`, `@bug`, `@summary`, `@run`
3. Run the test: `make test TEST=<path-to-test>`

### Debugging HotSpot
```bash
# Build with debug symbols
bash configure --with-debug-level=slowdebug
make images

# Run with additional logging
java -Xlog:gc*=debug -version
java -XX:+PrintFlagsFinal -version

# Common useful flags
-XX:+PrintCompilation    # See JIT compilation activity
-XX:+PrintGC             # GC logging
-XX:+TraceClassLoading   # Class loading activity
```

### Generating Compilation Database (for IDEs)
```bash
make compile-commands          # Full codebase
make compile-commands-hotspot  # HotSpot only (faster)
```

## Important Notes

- **Boot JDK requirement**: Building JDK N requires JDK N-1 installed
- **Disk space**: Builds require ~6GB free space
- **Memory**: Recommend 4-8GB RAM minimum, more for parallel builds
- **File paths**: Avoid spaces in paths, especially on Windows
- **Line endings**: On Windows with Git for Windows, set `core.autocrlf=false`
- **Test groups**: Check `test/*/TEST.groups` files for available test groups per component
- **Continuous testing**: tier1 tests run on GitHub Actions when enabled
- **Problem lists**: Tests in `ProblemList.txt` files are known to be unstable

## OpenJDK Development Guide

For comprehensive information beyond this file, see:
- Official guide: https://openjdk.org/guide/
- Building: `doc/building.md`
- Testing: `doc/testing.md`
- HotSpot style: `doc/hotspot-style.md`
- IDE setup: `doc/ide.md`
- Contributing: `CONTRIBUTING.md` → https://openjdk.org/guide/

## Bug Tracking and Changes

- Bug system: https://bugs.openjdk.org
- Commit message format: `<bug-id>: <summary>` (e.g., "8123456: Fix NPE in String.concat")
- Code review happens on GitHub PRs or mailing lists depending on project setup
