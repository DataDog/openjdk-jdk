# Java Flight Recorder (JFR) - Developer Context

This document provides comprehensive guidance for working with the Java Flight Recorder (JFR) subsystem in the OpenJDK.

## Overview

Java Flight Recorder (JFR) is a low-overhead profiling and diagnostics framework built into the JVM. It records detailed information about the JVM and Java application behavior with minimal performance impact (typically <1% overhead).

**Key Statistics:**
- **Java API**: 324 Java source files in `src/jdk.jfr/`
- **Native Code**: 317 C++ files in `src/hotspot/share/jfr/`
- **Event Definitions**: 171 event types defined in `metadata.xml`
- **Tests**: 706+ test files in `test/jdk/jdk/jfr/`

## Architecture

JFR consists of three main layers:

### 1. Native Recording Engine (HotSpot C++)
Located in `src/hotspot/share/jfr/`, this is the high-performance core that:
- Records events with minimal overhead using lock-free algorithms
- Manages thread-local buffers for event data
- Handles checkpointing and metadata serialization
- Controls the lifecycle of recordings

### 2. Java API Layer (jdk.jfr module)
Located in `src/jdk.jfr/share/classes/jdk/jfr/`, provides:
- **Public API**: Event definition, Recording control, Consumer API
- **Internal implementation**: Bridges to native layer via JNI

### 3. Tooling Layer
- Built-in `jfr` command-line tool for parsing/analyzing recordings
- JMX integration via `FlightRecorderMXBean`
- Support for external tools (JDK Mission Control, etc.)

## Source Code Organization

### Java Sources (`src/jdk.jfr/`)

```
jdk.jfr/share/classes/jdk/jfr/
├── Event.java                  # Base class for all events
├── Recording.java              # Recording lifecycle management
├── FlightRecorder.java         # Main entry point, singleton
├── EventSettings.java          # Configure individual event settings
├── Configuration.java          # Predefined configurations (.jfc files)
├── EventType.java              # Event metadata
├── EventFactory.java           # Dynamic event creation
│
├── consumer/                   # APIs for reading JFR files
│   ├── RecordingFile.java      # Parse .jfr files
│   ├── RecordingStream.java    # Stream events from ongoing recording
│   ├── EventStream.java        # Async event consumption
│   ├── RecordedEvent.java      # Represents a recorded event
│   ├── RecordedObject.java     # Base for all recorded data
│   ├── RecordedThread.java
│   ├── RecordedFrame.java
│   ├── RecordedStackTrace.java
│   └── RecordedMethod.java
│
├── events/                     # Predefined JDK event classes
│
├── internal/                   # Implementation (228 files)
│   ├── dcmd/                   # Diagnostic commands (jcmd integration)
│   ├── periodic/               # Periodic event sampling
│   ├── settings/               # Setting types (threshold, period, etc.)
│   ├── consumer/               # Consumer implementation
│   ├── management/             # JMX integration
│   ├── jfc/                    # JFC (configuration) file parsing
│   ├── tool/                   # jfr command-line tool
│   ├── event/                  # Event infrastructure
│   └── util/                   # Utilities
│
└── tracing/                    # Tracing framework support
```

### Native Sources (`src/hotspot/share/jfr/`)

```
hotspot/share/jfr/
├── jfr.hpp                     # Main VM interface to JFR
├── jfrEvents.hpp               # Include generated event classes
│
├── recorder/                   # Core recording engine
│   ├── jfrRecorder.cpp         # Main recorder lifecycle
│   ├── jfrEventSetting.cpp     # Event enable/disable logic
│   │
│   ├── service/                # Background services
│   │   ├── jfrRecorderService.cpp  # Main recording thread
│   │   └── jfrPostBox.cpp          # Thread communication
│   │
│   ├── storage/                # Event buffer management
│   │   ├── jfrStorage.cpp          # Thread-local buffers
│   │   ├── jfrBuffer.cpp           # Individual buffer
│   │   └── jfrMemorySpace.cpp      # Memory allocation
│   │
│   ├── stacktrace/             # Stack trace capture
│   │   └── jfrStackTraceRepository.cpp
│   │
│   ├── checkpoint/             # Metadata serialization
│   │   ├── jfrCheckpointManager.cpp
│   │   └── types/                  # Type serializers
│   │       └── traceid/            # TraceId assignment
│   │
│   ├── repository/             # Disk repository for .jfr files
│   │   └── jfrRepository.cpp
│   │
│   └── stringpool/             # String deduplication
│       └── jfrStringPool.cpp
│
├── writers/                    # Binary format writers
│   ├── jfrEventWriterHost.cpp
│   └── jfrJavaEventWriter.cpp
│
├── instrumentation/            # Bytecode instrumentation for events
│   └── jfrEventClassTransformer.cpp
│
├── periodic/                   # Periodic event generation
│   ├── jfrPeriodic.cpp
│   └── sampling/
│       └── jfrThreadSampler.cpp    # Thread CPU sampling
│
├── leakprofiler/              # Old object sample (memory leak detection)
│   ├── leakProfiler.cpp
│   ├── sampling/
│   ├── checkpoint/
│   └── chains/                 # Object reference chain tracking
│
├── dcmd/                      # Diagnostic command implementations
│   ├── jfrDcmds.cpp
│   └── jfrDcmds.hpp
│
├── jni/                       # JNI bridge to Java
│   └── jfrJavaSupport.cpp
│
├── utilities/                 # JFR-specific utilities
│   └── jfrTypes.hpp           # Type definitions
│
└── metadata/
    └── metadata.xml           # Event definitions (171 events)
```

## Event System

### Event Definition (metadata.xml)

Events are defined in `src/hotspot/share/jfr/metadata/metadata.xml`. Each event has:
- **name**: Event identifier (e.g., "ThreadStart", "GarbageCollection")
- **category**: Hierarchical category (e.g., "Java Application", "Java Virtual Machine, GC")
- **label**: Human-readable name
- **description**: Detailed explanation
- **fields**: Data fields with types and content types
- **attributes**:
  - `thread="true"`: Include thread information
  - `stackTrace="true"`: Capture stack trace
  - `startTime="true"`: Duration event (has begin/end)
  - `period="everyChunk"`: Periodic event
  - `internal="true"`: Development-only event
  - `experimental="true"`: Experimental API

Example event definition:
```xml
<Event name="JavaMonitorEnter" category="Java Application" label="Java Monitor Blocked"
       thread="true" stackTrace="true">
  <Field type="Class" name="monitorClass" label="Monitor Class" />
  <Field type="Thread" name="previousOwner" label="Previous Monitor Owner" />
  <Field type="ulong" contentType="address" name="address" label="Monitor Address" />
</Event>
```

### Event Code Generation

The build system processes `metadata.xml` to generate:
1. **C++ Event Classes**: `build/*/hotspot/variant-server/gensrc/jfrfiles/jfrEventClasses.hpp`
   - One class per event with typed field accessors
   - Used in HotSpot C++ code to commit events

2. **Java Event Classes**: Generated in `src/jdk.jfr/share/classes/jdk/jfr/events/`
   - Mirror C++ events for consistency
   - Used for event configuration and consumption

### Using Events in C++

```cpp
#include "jfr/jfrEvents.hpp"

void example_function() {
    // Duration event (has begin/end)
    EventDuration event;
    // ... do work ...
    event.commit();  // Records duration automatically

    // Instant event with fields
    EventThreadStart event;
    event.set_thread(thread);
    event.set_parentThread(parent);
    event.commit();

    // Check if event is enabled before expensive operations
    if (EventGarbageCollection::is_enabled()) {
        EventGarbageCollection event;
        // ... expensive data gathering ...
        event.commit();
    }
}
```

### Using Events in Java

```java
import jdk.jfr.*;

@Label("Custom Event")
@Description("Example custom event")
@Category("Application")
public class MyEvent extends Event {
    @Label("Message")
    String message;

    @Label("Value")
    long value;
}

// Usage
MyEvent event = new MyEvent();
event.message = "Something happened";
event.value = 42;
event.commit();

// Or with shouldCommit() check
MyEvent event = new MyEvent();
if (event.shouldCommit()) {
    event.message = expensiveOperation();
    event.commit();
}
```

## Configuration Files (.jfc)

Located in `src/jdk.jfr/share/conf/jfr/`:
- **default.jfc**: Low overhead (~1%), suitable for production
- **profile.jfc**: Higher overhead (~2%), more detailed profiling

These XML files control:
- Which events are enabled
- Event thresholds (e.g., only record GC pauses > 10ms)
- Sampling periods (e.g., thread samples every 20ms)
- Stack trace depth
- String size limits

## Recording Lifecycle

### Creating and Managing Recordings

**Programmatic (Java API):**
```java
// Create recording with configuration
Recording recording = new Recording(Configuration.getConfiguration("profile"));

// Or customize settings
Recording recording = new Recording();
recording.enable("jdk.ObjectAllocationSample")
         .withStackTrace()
         .with("throttle", "150/s");
recording.enable("jdk.CPUSample").with("period", "10ms");

// Start recording
recording.start();

// Stop and dump to file
recording.stop();
recording.dump(Path.of("myrecording.jfr"));
recording.close();
```

**Command-line:**
```bash
# Start at JVM startup
java -XX:StartFlightRecording=duration=60s,filename=recording.jfr MyApp

# With configuration
java -XX:StartFlightRecording=settings=profile,duration=60s MyApp

# Continuous recording with disk repository
java -XX:StartFlightRecording=disk=true,maxage=1h,maxsize=100M MyApp
```

**Runtime (jcmd):**
```bash
# Start recording
jcmd <pid> JFR.start name=myrecording settings=profile

# Dump recording
jcmd <pid> JFR.dump name=myrecording filename=recording.jfr

# Stop recording
jcmd <pid> JFR.stop name=myrecording
```

### Consuming Recordings

**Read from file:**
```java
try (RecordingFile recordingFile = new RecordingFile(Path.of("recording.jfr"))) {
    while (recordingFile.hasMoreEvents()) {
        RecordedEvent event = recordingFile.readEvent();
        System.out.println(event.getEventType().getName());
        System.out.println(event.getDuration());
        // Access fields
        if (event.hasField("message")) {
            System.out.println(event.getString("message"));
        }
    }
}
```

**Stream events (async):**
```java
try (RecordingStream rs = new RecordingStream()) {
    rs.enable("jdk.GarbageCollection").withThreshold(Duration.ofMillis(10));
    rs.onEvent("jdk.GarbageCollection", event -> {
        System.out.println("GC occurred: " + event.getDuration());
    });
    rs.start();  // Blocks or use startAsync()
}
```

## Key Subsystems

### 1. Thread-Local Buffers

JFR uses thread-local buffers to achieve low overhead:
- Each thread has a small buffer (typically 8KB) in native memory
- Events are written directly to the buffer (lock-free)
- When buffer fills, it's promoted to global storage
- Implementation: `src/hotspot/share/jfr/recorder/storage/`

### 2. Checkpointing

Checkpoints serialize type metadata and constant pools:
- Type definitions (event types, classes, methods)
- Constant pool entries (deduplicated strings, symbols)
- Written periodically and at chunk boundaries
- Implementation: `src/hotspot/share/jfr/recorder/checkpoint/`

### 3. Stack Trace Repository

Efficiently stores stack traces:
- Deduplicates identical stack traces
- Assigns each unique trace an ID
- Only the ID is stored with each event
- Implementation: `src/hotspot/share/jfr/recorder/stacktrace/`

### 4. TraceId System

Assigns unique IDs to Java types (classes, methods, etc.):
- Used for compact event representation
- Enables efficient serialization
- Implementation: `src/hotspot/share/jfr/recorder/checkpoint/types/traceid/`

### 5. Leak Profiler (Old Object Sample)

Tracks objects that survive multiple GC cycles:
- Identifies potential memory leaks
- Records allocation stack trace
- Builds reference chains to GC roots
- Implementation: `src/hotspot/share/jfr/leakprofiler/`

### 6. Thread Sampler

Periodic sampling of thread states:
- Captures stack traces at intervals (default 20ms)
- Minimal impact using VM thread or async sampling
- Implementation: `src/hotspot/share/jfr/periodic/sampling/jfrThreadSampler.cpp`

## Testing JFR

### Test Organization

Tests are in `test/jdk/jdk/jfr/` organized by:
- **api/**: Public API tests
- **event/**: Tests for specific event types
- **jvm/**: VM-level event tests
- **jcmd/**: jcmd integration tests
- **jmx/**: JMX integration tests
- **tool/**: jfr command-line tool tests
- **startupargs/**: JVM startup argument tests

### Running JFR Tests

```bash
# All JFR tests
make test TEST=jdk/jfr

# Specific subdirectory
make test TEST=test/jdk/jdk/jfr/api

# Single test
make test TEST=test/jdk/jdk/jfr/api/consumer/TestRecordingFile.java

# With JFR enabled (some tests require this)
make test TEST=jdk/jfr JTREG="JAVA_OPTIONS=-XX:StartFlightRecording"
```

### Writing JFR Tests

JFR tests typically use the test infrastructure in `test/lib/jdk/test/lib/jfr/`:
- `EventNames.java`: Constants for event names
- `Events.java`: Utilities for asserting event properties
- `SimpleEvent.java`: Simple test events

Example test pattern:
```java
@Test
public void testMyEvent() throws Exception {
    Recording r = new Recording();
    r.enable(EventNames.MyEvent);
    r.start();

    // Trigger event
    triggerEvent();

    r.stop();

    // Verify events
    List<RecordedEvent> events = Events.fromRecording(r);
    Events.hasEvents(events);
    RecordedEvent event = events.get(0);
    Events.assertField(event, "myField").equal(expectedValue);
}
```

## Common Development Tasks

### Adding a New Event

1. **Define event in metadata.xml**:
```xml
<Event name="MyNewEvent" category="Java Application" label="My New Event"
       thread="true" stackTrace="true">
  <Field type="string" name="message" label="Message" />
  <Field type="long" name="value" label="Value" />
</Event>
```

2. **Rebuild to generate event classes**:
```bash
make hotspot
```

3. **Use the event in C++ code**:
```cpp
#include "jfr/jfrEvents.hpp"

EventMyNewEvent event;
event.set_message("test");
event.set_value(123);
event.commit();
```

4. **Add tests** in `test/jdk/jdk/jfr/event/`:
```java
public class TestMyNewEvent {
    @Test
    public void test() throws Exception {
        Recording r = new Recording();
        r.enable("jdk.MyNewEvent");
        r.start();
        // trigger event
        r.stop();
        // assert events
    }
}
```

### Modifying Event Definition

1. Update `metadata.xml`
2. Rebuild: `make hotspot`
3. Update any code using the event
4. Update/add tests
5. Run tests: `make test TEST=jdk/jfr`

### Debugging JFR Issues

**Enable JFR logging:**
```bash
java -Xlog:jfr=debug:file=jfr.log -XX:StartFlightRecording MyApp
```

**Common log tags:**
- `jfr`: General JFR operations
- `jfr+event`: Event recording
- `jfr+system`: System-level operations
- `jfr+dcmd`: Diagnostic commands

**Check recording state:**
```bash
jcmd <pid> JFR.check
```

**Dump internal structures:**
```bash
# In debug builds
jcmd <pid> JFR.dump name=myrecording filename=out.jfr
```

### Performance Considerations

JFR is designed for low overhead, but be aware:

1. **Event frequency**: High-frequency events need careful optimization
   - Use `shouldCommit()` to avoid work if event disabled
   - Keep event fields minimal
   - Avoid allocations in event code path

2. **Stack traces**: Expensive to capture
   - Only enable for important events
   - Control depth with `stacktrace="true"` and JFC settings

3. **String fields**: Copied and deduplicated
   - Limit string sizes in JFC files
   - Avoid large strings in high-frequency events

4. **Periodic events**: Run on recorder thread
   - Keep periodic event callbacks fast
   - Avoid locks and allocations

## Build Integration

JFR is built as part of the standard HotSpot build:

1. **metadata.xml processing**: Generates event classes at build time
2. **JNI registration**: `jfr_register_natives()` called during VM startup
3. **Module compilation**: jdk.jfr module built after java.base

**Conditional compilation:**
- JFR is always enabled in modern JDK (no conditional compilation)
- Legacy: `INCLUDE_JFR` macro (always defined now)

## Configuration Reference

### JVM Flags

```bash
# Start recording at startup
-XX:StartFlightRecording=<options>

# Options for StartFlightRecording:
# - name=<name>                  Recording name
# - settings=<profile|default>   Configuration file
# - duration=<time>              Recording duration (e.g., 60s, 5m)
# - filename=<path>              Output file
# - disk=<true|false>           Use disk repository
# - maxage=<time>               Maximum age of data (e.g., 1h)
# - maxsize=<size>              Maximum recording size (e.g., 100M)
# - dumponexit=<true|false>     Dump recording on JVM exit

# Flight Recorder options
-XX:FlightRecorderOptions=<options>

# Options for FlightRecorderOptions:
# - stackdepth=<depth>          Stack trace depth (default 64)
# - globalbuffersize=<size>     Global buffer size
# - threadbuffersize=<size>     Thread buffer size (default 8K)
# - memorysize=<size>           Total memory for JFR
# - maxchunksize=<size>         Maximum chunk size
# - samplethreads=<true|false>  Enable thread sampling
```

### jcmd Commands

```bash
JFR.start [options]          # Start recording
JFR.stop [options]           # Stop recording
JFR.dump [options]           # Dump recording to file
JFR.check [verbose]          # Check recording status
JFR.configure [options]      # Configure Flight Recorder
```

## Important Implementation Notes

### Memory Management

- Event buffers allocated from native memory (not Java heap)
- Thread-local buffers created on-demand
- Global buffers managed by storage system
- Old buffers released during chunk rotation

### Thread Safety

- Thread-local writes are lock-free
- Global operations (checkpointing, chunk rotation) use locks
- Event writing uses relaxed memory ordering where safe
- Critical sections minimized for low latency

### JNI Boundary

The JNI layer (`src/hotspot/share/jfr/jni/jfrJavaSupport.cpp`) bridges:
- Java Recording API → Native recorder
- Native events → Java metadata
- Configuration → Native settings

### Integration Points

JFR hooks into HotSpot at key lifecycle points (`jfr.hpp`):
- VM initialization: `Jfr::on_create_vm_*`
- Thread lifecycle: `Jfr::on_thread_start/exit`
- Class loading: `Jfr::on_klass_creation`
- Method resolution: `Jfr::on_resolution`
- VM shutdown: `Jfr::on_vm_shutdown`

## Related Documentation

- JFR API Javadoc: `src/jdk.jfr/share/classes/jdk/jfr/package-info.java`
- Event metadata: `src/hotspot/share/jfr/metadata/metadata.xml`
- JEP 328: Flight Recorder (OpenJDK 11)
- JEP 349: JFR Event Streaming (OpenJDK 14)

## Typical Bug Patterns to Avoid

1. **Missing `is_enabled()` check**: Always check before expensive data gathering
2. **Holding locks during commit()**: Can cause deadlocks with recorder thread
3. **Allocating in event path**: Increases overhead, may cause OOM
4. **Large string fields**: Use bounded sizes, consider using IDs + lookup table
5. **Stack overflow in events**: Be careful with stack trace depth
6. **Race conditions in periodic events**: Use proper synchronization
7. **Memory leaks in leak profiler**: Ensure weak references used appropriately

## Contact and Resources

- OpenJDK JFR documentation: https://openjdk.org/jeps/328
- JDK Mission Control (JMC): External analysis tool for JFR recordings
- JFR mailing list: serviceability-dev@openjdk.org
